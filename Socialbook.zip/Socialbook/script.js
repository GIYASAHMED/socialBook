// body color changer
const darkBtn = document.querySelector('#dark-btn')
const webBody = document.querySelector('body')

function changeColor() {
    darkBtn.addEventListener('click', () => {
        darkBtn.classList.toggle('dark-btn-on');
        webBody.classList.toggle("dark-theme");

        if (localStorage.getItem("theme") == "light") {
            localStorage.setItem("theme", "dark");
        }
        else {
            localStorage.setItem("theme", "light");
        }
        
    })
}
if (localStorage.getItem("theme") == "light") {
    darkBtn.classList.remove("dark-btn-on");
    webBody.classList.remove("dark-theme");
} else if (localStorage.getItem("theme") == "dark") {
    darkBtn.classList.add("dark-btn-on");
    webBody.classList.add("dark-theme");
} else {
    localStorage.setItem("theme", "light")
}
changeColor();


//-------------- Toggle Settings Menu ---------------
const settingsMenu = document.querySelector('.settings-menu');
console.log(settingsMenu);

function settingsMenuToggle() {
    settingsMenu.classList.toggle('settings-menu-height');
}